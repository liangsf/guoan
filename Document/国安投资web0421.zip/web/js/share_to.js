function share_to(m,title,url) {
	
     if (m == "tsina") {
        void ((function(s, d, e) {
            try {

            } catch (e) {

            }
            var f = 'http://v.t.sina.com.cn/share/share.php?', u = url, p = [
                    'url=', e(u), '&title=', e(title), '&appkey=330242870' ]
                    .join('');

            function a() {

                if (!window.open(

                                [ f, p ].join(''),

                                'mb',

                                [

                                        'toolbar=0,status=0,resizable=1,width=620,height=450,left=',

                                        (s.width - 620) / 2, ',top=',

                                        (s.height - 450) / 2 ].join('')))

                    u.href = [ f, p ].join('');

            }

            ;

            if (/Firefox/.test(navigator.userAgent)) {

                setTimeout(a, 0)

            } else {

                a()

            }

        })(screen, document, encodeURIComponent));

    } else if (m == "douban") {

        void (function() {

            var d = document, e = encodeURIComponent, s1 = window.getSelection, s2 = d.getSelection, s3 = d.selection, s = s1 ? s1()

                    : s2 ? s2() : s3 ? s3.createRange().text : '', r = 'http://www.douban.com/recommend/?url='

                    + e(d.location.href)

                    + '&title='

                    + e(d.title)

                    + '&sel='

                    + e(s) + '&v=1', x = function() {

                if (!window

                        .open(r, 'douban',

                                'toolbar=0,resizable=1,scrollbars=yes,status=1,width=450,height=355,left='

                                    + (screen.width - 450) / 2 + ',top='

                                    + (screen.height - 330) / 2))

                    location.href = r + '&r=1'

            };

            if (/Firefox/.test(navigator.userAgent)) {

                setTimeout(x, 0)

            } else {

                x()

            }

        })();

    } else if (m == "renren") {

        // 官方分享方式2

         void ((function(s, d, e) {

         if (/renren\.com/.test(d.location))

         return;

         var f = 'http://share.renren.com/share/buttonshare.do?link=', u =

         d.location, l = d.title, p = [

         e(u), '&title=', e(l) ].join('');

         function a() {

         if (!window

         .open(

         [ f, p ].join(''),

         'xnshare',

         [

         'toolbar=0,status=0,resizable=1,width=626,height=436,left=',

         (s.width - 626) / 2, ',top=',

         (s.height - 436) / 2 ].join('')))

         u.href = [ f, p ].join('');

         }

         ;

         if (/Firefox/.test(navigator.userAgent))

         setTimeout(a, 0);

         else

         a();

         })(screen, document, encodeURIComponent));

    }  else if (m == "tqq") {

        var _t = encodeURI(title);

        var _url = encodeURIComponent(url);

        var _appkey = encodeURI("appkey");//你从腾讯获得的appkey

        var _pic = encodeURI('');//（例如：var _pic='图片url1|图片url2|图片url3....）

        var _site = '';//你的网站地址

        var _u = 'http://v.t.qq.com/share/share.php?url='+_url+'&appkey='+_appkey+'&site='+_site+'&pic='+_pic+'&title='+_t;

        window.open( _u,'', 'width=700, height=680, top=0, left=0, toolbar=no, menubar=no, scrollbars=no, location=yes, resizable=no, status=no' );

    }



    // 33twwiter,facebook,digu,有道,白社会(mop),csdn,yahoo bazz,myspace.com(参考chinadaily.com.cn)

    // 待开发:和讯微博

    return false;

}