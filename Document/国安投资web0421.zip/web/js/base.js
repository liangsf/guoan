// JavaScript Document
$(function(){
		//DD_belatedPNG.fix('.header,.nav ul.menu li span a,.main_conter,.main_bottom,.pagination li a')
	
	(function(){
	var cmsDialog = {
		/**
		 * [弹出层配置]
		 * @type {Object}
		 */
		config: {
			/**插件是否调用*/
			flag: false
		},
		/**
		 * 加载弹出层插件后执行回调
		 * @param  {Function} callback 回调函数
		 */
		load: function(callback) {
			var self = this;
			$.ajax({
				url: 'http://imgcdn.house.sina.com.cn/2.0/bbs/js/artDialog.js?skin=default',
				dataType: "script",
				cache:true,
				success: function() {
					$.getScript('http://imgcdn.house.sina.com.cn/2.0/bbs/js/plugins/iframeTools.js', function() {
						self.config.flag = true;
						(function(config) {
							config['lock'] = true;
							config['fixed'] = true;
							config['okVal'] = '确定';
							config['cancelVal'] = '取消';
							config['opacity'] = 0.3;
							config['zIndex'] = 10000;
							config['resize'] = false;
							config['esc'] = true;
						})(art.dialog.defaults);
						callback && callback(window.art);
					});
				}
			});
			
		},
		check:function(node,callback){
			if (!callback) {return false;}
			if (window.art) {
				callback(window.art);
			} else {
				this.load(callback);
			}
		}
	}
	window.cmsDialog = cmsDialog;
	})();
	GUOAN.onLoad();
})


var GUOAN = {};
GUOAN.namespace = function(str){
	var arr = str.split('.'),o=GUOAN;
	for(i=(arr[0]=='GUOAN')?1:0; i<arr.length; i++){		
		o[arr[i]] = o[arr[i]] || {};
		o = o[arr[i]];
	}
}
GUOAN.namespace('onLoad');
GUOAN.namespace('Page.isIE6');



GUOAN.Page.menuCurrent = function(){
	var nm = GUOAN.Page.get(window.location.href,'menu');
	var nv = GUOAN.Page.get(window.location.href,'nav');
	if(nv){
		nm = parseInt(nm);
		nv = parseInt(nv);
		$('ul.menu li:eq('+nm+')').addClass('cur');
		$('.ny_nav_c ul li:eq('+nv+')').addClass('cur');
	}
}

GUOAN.Page.get = function(url, key) {
	var escapeReg = function(source) {
		return String(source)
				.replace(new RegExp("([.*+?^=!:\x24{}()|[\\]\/\\\\])", "g"), '\\\x241');
	};
    var reg = new RegExp(
                        "(^|&|\\?|#)" 
                        + escapeReg(key) 
                        + "=([^&]*)(&|\x24)", 
                    "");
    var match = url.match(reg);
    if (match) {
		var result=match[2].substring(match[2].length-1,match[2].length);
        return result=='#'?match[2].substring(0,match[2].length-1):match[2];
    }
    
    return null;
}


GUOAN.Page.isIE6 = function(){
	var isIE = !+'\v1'; //IE浏览器
	var IE6 = isIE && /MSIE (\d)\./.test(navigator.userAgent) && parseInt(RegExp.$1) < 7;
	return IE6;	
}

GUOAN.Page.menuHover=function(){
	$('#menu_hover li').hover(function(){
		var div = $(this).find('div.subbox');
			if(div.length>0){
				div.show();	
			}
		},function(){
			$(this).find('div.subbox').hide();
			
		})
}

GUOAN.Page.tabCuren=function(ul,div){
	$(ul + ' li').on('mouseover',function(){
		$(ul + ' li').removeClass('cur');
		$(this).addClass('cur');
		var index = $(this).index();
		$(div).hide();
		$(div + ':eq('+index+')').show();
	})
}

GUOAN.Page.indexProHover=function(){
	$('.index_pro li a').each(function(index, element) {
        $(this).on('click',function(){
			$('.scrollUl').css('top',index*(-218) + 'px');
			$('.proHover').fadeIn(500);
			GUOAN.Page.indexProScroll(index);
		})
    });
	
	$('.proHover a.close').on('click',function(){
		$('.proHover').fadeOut(500);
	})
}
GUOAN.Page.indexProScroll = function(index){
	var leg = index;
	$('.proHover .next').on('click',function(){
		if(leg < 2){
			leg ++;
			$('.scrollUl').animate({'top':leg*-218 + 'px'},500)	;
		}else if(leg == 2){
			leg=0;	
			$('.scrollUl').animate({'top':leg*-218 + 'px'},500)	;
		}
	})
}

GUOAN.Page.textSize=function(tab,content){
	$('.textSize a').on('click',function(){
		$('.textSize a').removeClass('cur');
		$(this).addClass('cur');
		var size = 'size' + $(this).attr('rel');
		$('#zhengwen').removeClass();
		$('#zhengwen').addClass(size);
	})
	
}

GUOAN.Page.cityChange=function(tab,content){
	$('#citychange').on('click',function(event){
		event.stopPropagation();
		$('.city_select').show();		
	})
	$(document).bind('click',function(){
		$('.city_select').hide();
	})
}


GUOAN.Page.floatRight=function(){
	var currentPosition = parseInt($(".floatRight").css("top"));
    $(window).scroll(function() {
        var position = $(window).scrollTop();
        $(".floatRight").stop().animate({"top":position+currentPosition+"px"},250);
    });
}
GUOAN.Page.feedBack=function(){
	cmsDialog.check(null, function(art) {
	$('#feedbackTc').on('click',function(){
		var url = $(this).attr('rel');
		var dialog = art.dialog({id: 'N3690',title: false,padding:0});
	// jQuery ajax   
		$.ajax({
			url: url,
			dataType:"html",
			success: function (data) {
				dialog.content(data);
				$('.aui_close').css({
					"width":"30px",
					"height":"30px",
					"backgroundColor":"#d7181f",
					"lineHeight":"30px",
					"fontSize":"30px",
					"color":"#fff",
					"textShadow":"0 0 0 rgba(255, 255, 255, 0)",
					"top":0,
					"right":"-30px"
				});
			},
			cache: false
		});
	})
	})
}

GUOAN.Page.productPont=function(){
	$('.dichan_map_pic .pont').hover(function(){
		$(this).removeClass('anmted');
	},function(){
		$(this).addClass('anmted');
	})
}
GUOAN.Page.slecter=function(){
	$('.slecter').on('click',function(event){
		event.stopPropagation();
		$(this).addClass('slect_box2');
		$('.slect_box').show();		
	})
	$('a.weixin').on('click',function(event){
		event.stopPropagation();
		$(this).find('.weixin_ewm').show();
	})
	$(document).bind('click',function(){
		$('.slect_box').hide();
		$('.weixin_ewm').hide();
		$('.slecter').removeClass('slect_box2');
	})
}
GUOAN.Page.closeArt=function(){
	var list = art.dialog.list;
	for (var i in list) {
		list[i].close();
	};
}

GUOAN.onLoad = function(){
	GUOAN.Page.menuHover();
	GUOAN.Page.productPont();
	GUOAN.Page.slecter();
	GUOAN.Page.floatRight();
}

